   <div class="sidebar" data-color="white" data-active-color="danger">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
      <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-mini">
          <div class="logo-image-small">
            <img src="../assets/img/logo-small.png">
          </div>
        </a>
        <a href="http://www.creative-tim.com" class="simple-text logo-normal">
          Admin
          <!-- <div class="logo-image-big">
            <img src="../assets/img/logo-big.png">
          </div> -->
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <!--li>
            <a href="./dashboard.html">
              <i class="nc-icon nc-bank"></i>
              <p>Dashboard</p>
            </a>
          </li--->
		  
		   <li>
            <a href="city.php">
              <i class="nc-icon nc-diamond"></i>
              <p>City  Add</p>
            </a>
          </li>
		  
		  
         <li>
            <a href="category.php">
              <i class="nc-icon nc-diamond"></i>
              <p>Category Add</p>
            </a>
          </li>
		  
		 
		  
		      <li>
            <a href="product.php">
              <i class="nc-icon nc-diamond"></i>
              <p>Product Add</p>
            </a>
          </li>
		  
		    <li>
            <a href="showcustomer.php">
              <i class="nc-icon nc-diamond"></i>
              <p>Show Customer</p>
            </a>
          </li>
		  
		  
		  <li>
            <a href="order.php">
              <i class="nc-icon nc-diamond"></i>
              <p>Show Order</p>
            </a>
          </li>
		   
		 
		 <li>
            <a href="show_contect.php">
              <i class="nc-icon nc-diamond"></i>
              <p>Show Contact </p>
            </a>
          </li>

          
          <li>
            <a href="show_Complain.php">
              <i class="nc-icon nc-diamond"></i>
              <p>Show Complain </p>
            </a>
          </li>
		 

          <li>
            <a href="show_Feedback.php">
              <i class="nc-icon nc-diamond"></i>
              <p>Show Feedback </p>
            </a>
          </li>
		  
		  <li>
            <a href="indexvvv.php">
              <i class="nc-icon nc-diamond"></i>
              <p>Satyam Data </p>
            </a>
          </li>
		 
		 
        </ul>
      </div>
    </div>
