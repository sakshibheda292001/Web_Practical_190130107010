<?php include('config.php'); ?>
<?php 
$id = $_GET['id'];
$sql = ("DELETE from product WHERE p_id='$id'");
$result = mysqli_query($conn,$sql); 
echo '<script type="text/javascript">location.replace("product.php");</script>';
?>