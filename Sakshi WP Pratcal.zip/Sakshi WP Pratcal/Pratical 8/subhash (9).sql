-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 14, 2019 at 07:04 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `subhash`
--

-- --------------------------------------------------------

--
-- Table structure for table `login1`
--

CREATE TABLE IF NOT EXISTS `login1` (
  `User_Id` int(4) NOT NULL AUTO_INCREMENT,
  `post_email` varchar(30) NOT NULL,
  `post_pass` varchar(30) NOT NULL,
  PRIMARY KEY (`User_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `login1`
--

INSERT INTO `login1` (`User_Id`, `post_email`, `post_pass`) VALUES
(4, 'mayank@gmail.com', 'mayank888'),
(5, 'raj@gmail.com', 'rajukaka'),
(6, 'pk@gmail.com', 'pk'),
(7, 'raju@gmail.com', 'rajubhai'),
(8, 'nishi@gmail.in', 'tinnabeniiii');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `post_id` int(4) NOT NULL AUTO_INCREMENT,
  `post_content` varchar(200) NOT NULL,
  `post_title` varchar(100) NOT NULL,
  `post_date` date NOT NULL,
  `post_author` varchar(100) NOT NULL,
  `post_image` varbinary(200) NOT NULL,
  `post_keywords` varchar(100) NOT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=69 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `post_content`, `post_title`, `post_date`, `post_author`, `post_image`, `post_keywords`) VALUES
(13, 'ddsf', 'sdf', '2017-11-29', 'sf', 'DriverAdmin1.jpg', 'sdgf'),
(14, 'zcsf', 'ss', '2017-12-29', 'sdf', 's3.jpg', 'sd'),
(15, 'sdsad', 'aasda', '2017-12-29', 'asd', 's3.jpg', 'asa'),
(16, 'my name is don', 'thedon', '2017-12-29', 'sdf', 's3.jpg', 'sdf'),
(30, 'this is testing web site by megha', 'My Title', '2019-05-15', 'Megha', 'a.jpg', 'note book pen'),
(31, 'Hello this is viral sir', 'Viral', '2019-05-16', 'Viral sir ', 'bikeimage.jpg', 'viral viral'),
(32, 'This is testing project ', 'Vina', '2019-05-16', 'vina patel', 'b.jpg', 'vina patel charotar anand'),
(33, 'This is testing page of chetan', 'chetan post', '2019-05-31', 'chetan', 'b.jpg', 'chetan manoj'),
(34, 'this is testing of data image', 'pankaj', '2019-07-01', 'pk', '2019-01-09 at 22-16-59.png', 'k kp pk'),
(35, 'sdfdsf', 'sdf', '2019-07-04', 'sdf', '2019-01-09 at 22-16-59.png', 'sdf'),
(36, 'sdfdfs', 'sdfsd', '2019-07-04', 'sdf', '2019-03-23 at 16-01-38.png', 'sdf'),
(37, 'sdffsdf', 's', '2019-07-04', 'sd', '2019-03-23 at 16-01-38.png', 'sddf'),
(38, 'sfdsfs', 'sdf', '2019-07-04', 'sdf', '2019-03-23 at 16-01-38.png', 'sdf'),
(39, 'sdfsf', 'sdf', '2019-07-04', 'sdf', '2019-01-09 at 22-16-59.png', 'sdf'),
(40, 'sdfsdf', 'sdf', '2019-07-04', 'sdf', '2019-03-23 at 16-01-38.png', 'sdf'),
(41, 'sdfsdf', 'sdf', '2019-07-04', 'sdf', '2019-03-23 at 16-01-38.png', 'sdf'),
(42, 'sdf', 'sd', '2019-07-04', 'sd', '2019-03-23 at 16-01-38.png', 'sdf'),
(43, 'fsdfsd', 'sd', '2019-07-04', 'sdf', '2019-01-09 at 22-16-59.png', 'qsdf'),
(44, 'fsdfsd', 'sd', '2019-07-04', 'sdf', '2019-01-09 at 22-16-59.png', 'qsdf'),
(45, 'sdfsdf', 'sdf', '2019-07-04', 'sdf', '2019-01-09 at 22-16-59.png', 'sdf'),
(46, 'sdfsdf', 'sdf', '2019-07-04', 'sdf', '2019-01-09 at 22-16-59.png', 'sdf'),
(47, 'sdfdsf', 'fsdf', '2019-07-04', 'sdf', '2019-01-09 at 22-16-59.png', 'sdf'),
(48, 'sdfdsf', 'sdf', '2019-07-04', 'sdf', '2019-03-23 at 16-01-38.png', 'sfd'),
(49, 'sdfsdf', 'sdfs', '2019-07-04', 'sdf', '2019-03-23 at 16-01-38.png', 'sdf'),
(50, 'sdfsdf', 'sdf', '2019-07-04', 'sd', '2019-01-09 at 22-16-59.png', 'sfd'),
(51, 'sdfsdf', 'sdf', '2019-07-04', 'sd', '2019-01-09 at 22-16-59.png', 'sfd'),
(52, 'sdfsdf', 'sdf', '2019-07-04', 'sd', '2019-01-09 at 22-16-59.png', 'sfd'),
(53, 'sfsdfs', 'sdf', '2019-07-04', 'sf', '2019-03-23 at 16-01-38.png', 'sdf'),
(54, 'sfsdfs', 'sdf', '2019-07-04', 'sf', '2019-03-23 at 16-01-38.png', 'sdf'),
(55, 'qqeqw', 'sdf', '2019-07-04', 'sdf', '2019-01-09 at 22-16-59.png', 'sdf'),
(56, 'qqeqw', 'sdf', '2019-07-04', 'sdf', '2019-01-09 at 22-16-59.png', 'sdf'),
(57, 'qqeqw', 'sdf', '2019-07-04', 'sdf', '2019-01-09 at 22-16-59.png', 'sdf'),
(58, 'sfdsf', 'sdf', '2019-07-04', '`sdf', '2019-01-09 at 22-16-59.png', 'sf`f'),
(59, 'sfdsfsdfsd', 'sdfds', '2019-07-04', 'sdf', '2019-01-09 at 22-16-59.png', 'sf'),
(60, 'sdsfsdf', 'sdfsf', '2019-07-04', 'sdf', '2019-01-09 at 22-16-59.png', 'sdf'),
(61, 'sdsfsdf', 'sdfsf', '2019-07-04', 'sdf', '2019-01-09 at 22-16-59.png', 'sdf'),
(62, 'fdsfsdfs', 'sfdsf', '2019-07-04', 'sdf', '2019-01-09 at 22-16-59.png', 'sdf'),
(63, 'sfdsf', 'sdfds', '2019-07-04', 'sf', '2019-01-09 at 22-16-59.png', 'sdf'),
(64, 'sfdsf', 'sdfds', '2019-07-04', 'sf', '2019-01-09 at 22-16-59.png', 'sdf'),
(65, 'ssdfsdf', 'sdf', '2019-07-04', 'sdf', '2019-03-23 at 16-01-38.png', 'sdf'),
(66, 'ssdfsdf', 'sdf', '2019-07-04', 'sdf', '2019-03-23 at 16-01-38.png', 'sdf'),
(67, 'ssdfsdf', 'sdf', '2019-07-04', 'sdf', '2019-03-23 at 16-01-38.png', 'sdf'),
(68, 'sfsfsdfsdfsdf', 'sdf', '2019-07-04', 'sdf', '2019-03-23 at 16-01-38.png', 'sdf');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
