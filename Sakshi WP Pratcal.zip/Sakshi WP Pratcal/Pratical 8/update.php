<?php
require_once "dbconfig.php";
error_reporting(0);

echo $_GET['rn'];
echo $_GET['sn'];
echo $_GET['c1'];



?>

<html>
<head>
</head>
<body>
<form action="" method="GET">
User Id<input type="text" name="userid" value="<?php echo $_GET['rn']; ?>"/><br><br>
Email<input type="text" name="studentname" value="<?php echo $_GET['sn']; ?>"/><br><br>
Pass<input type="text" name="class"value="<?php echo $_GET['c1']; ?>"/><br><br>
<input type="submit" name="submit" value="update"/>
</form>
<?php
if($_GET['submit'])
		
		{

		$uid =$_GET['userid'];	
		$email =$_GET['studentname'];
		$pass =$_GET['class'];	
		$query ="UPDATE login1 set post_email='$email',post_pass='$pass' where User_Id='$uid' ";
$data =mysqli_query($con,$query);
	if($data)
		{
		echo "<font color='green'> Record Update,<a href='manage.php'>  Check Update List Here</a>";
		}
		else
		{
		echo "<font color='red'>Record not Updated <a href='manage.php'>  Check Update List Here</a>";
		}

		}
		else
		{
		echo "<font color='black'>Click on Update Button to Save Changes";
		}
	

	
?>

</br></br></br></br></br></br></br>
<a href="resume.html" class="nav-link">resume</a></li>
<a href="time_table.html" class="nav-link">timetable</a></li>
<a href="cal.html" class="nav-link">Calculator</a></li>
	

	
</body>
</html>
</br></br></br></br></br></br></br>
<center>
<p> Sakshi Bheda Er No 190130107010 </p>
</center>
