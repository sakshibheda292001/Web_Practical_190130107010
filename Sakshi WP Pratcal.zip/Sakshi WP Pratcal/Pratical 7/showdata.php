<?php
require_once "dbconfig.php";

error_reporting(0);

$sql = "select * from login1";
$result  =mysqli_query($con,$sql);
$total =mysqli_num_rows($result);

if($total !=0)
		{

		while($result1 =mysqli_fetch_assoc($result))
			{
		echo $result1[User_Id]. "    xxx " .$result1['post_email']. "     xxx" .$result1['post_pass']."<br/>";			}
		}
		else
		{
		echo "No Record Found";
		}

?>
