<?php
require_once 'dbconfig.php';
if(isset($_POST['submit']))
{

	$post_email=$_POST['email'];
	$post_pass=$_POST['password'];
	if($post_email=='' or $post_pass=='')
	{
		echo "Enter Something";
		exit();
	}
	else
	{
			$sql="insert into login1(post_email,post_pass) Value('$post_email','$post_pass')";
	
		if(mysqli_query($con,$sql))
		{
			echo "Record Saved...";
		}
		else
		{
		echo "Not Saved..";
		}
	}
}
?>