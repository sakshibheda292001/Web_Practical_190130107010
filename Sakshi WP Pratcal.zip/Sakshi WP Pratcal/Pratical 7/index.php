<html>
<head>
<title>www.spectra.com</title>
</head>
<body>
<form method="POST" action="mydata.php" enctype="multipart/form-data" >
<table align="center" width="900" border="5" >
<tr>
<td bgcolor="yellow" align="center" colspan="6">
<h2>Insert Record</h2></td>
</tr>

<tr>
<td align="right">Email ID</td>
<td><input type="text" name="email"></td>
</tr>

<tr>
<td align="right">Password</td>
<td><input type="text" name="password"></td>
</tr>


<tr>
<td align="center" colspan="6"><input type="submit" name="submit" value="Login"></td>
</tr>
</table>
</form>
</body>
</html>


